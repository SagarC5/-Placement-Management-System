# Flask Auth Project

Flask backend with session-based login for your static frontend.

## Setup
1. Install Python 3.9+ and pip
2. In this folder, run:
   ```bash
   pip install -r requirements.txt
   python app.py
   ```
3. Visit http://localhost:5000/login.html to log in

## Pre-created Users
- student1 / Student@123 (role: student)
- faculty1 / Faculty@123 (role: faculty)
- tpo1 / Tpo@123 (role: tpo)
