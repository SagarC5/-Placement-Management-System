from flask import Flask, request, session, redirect, jsonify, send_from_directory, render_template
from werkzeug.security import generate_password_hash, check_password_hash
from pymongo import MongoClient
from dotenv import load_dotenv
import os

import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
import random, string
from flask import current_app

def generate_password(length=8):
    chars = string.ascii_letters + string.digits
    return ''.join(random.choice(chars) for _ in range(length))

def send_email(to_email, subject, body):
    sender_email = os.getenv("EMAIL_ADDRESS")
    sender_password = os.getenv("EMAIL_PASSWORD")
    if not sender_email or not sender_password:
        print("Email credentials not set in environment (.env). Skipping email send.")
        return False

    msg = MIMEMultipart()
    msg['From'] = sender_email
    msg['To'] = to_email
    msg['Subject'] = subject
    msg.attach(MIMEText(body, 'plain'))

    try:
        with smtplib.SMTP_SSL('smtp.gmail.com', 465) as server:
            server.login(sender_email, sender_password)
            server.send_message(msg)
        return True
    except Exception as e:
        print("Failed to send email:", e)
        return False


# === Load environment variables ===
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
load_dotenv(os.path.join(BASE_DIR, ".env"))

PUBLIC_DIR = os.path.join(BASE_DIR, "public")

app = Flask(__name__, static_folder="public", template_folder="templates")
app.secret_key = os.getenv("SECRET_KEY", "change-this-secret")

# === MongoDB Atlas Connection ===
MONGO_URI = os.getenv("MONGO_URI")
client = MongoClient(MONGO_URI, serverSelectionTimeoutMS=5000)

try:
    client.admin.command("ping")
    print("✅ MongoDB connected successfully!")
except Exception as e:
    print("❌ MongoDB connection failed:", e)

db = client["placement_db"]
users_collection = db["users"]

print("Databases:", client.list_database_names())
print("Collections in placement_db:", db.list_collection_names())

# === Serve static files ===
@app.route("/<path:filename>")
def static_files(filename):
    return send_from_directory(app.static_folder, filename)

@app.route("/")
def index():
    return send_from_directory(app.static_folder, "index.html")

# === Register API ===
@app.route("/api/register", methods=["POST"])
def register():
    data = request.json
    print("Register API called with:", data)

    usn = data.get("usn")
    email = data.get("email")
    phone = data.get("phone")
    username = data.get("username")
    role = data.get("role")

    if not usn or not email or not phone or not username or not role:
        return jsonify({"error": "All fields are required"}), 400

    if users_collection.find_one({"username": username}):
        return jsonify({"error": "User already exists"}), 400

    # Generate a random password and hash it
    plain_password = generate_password(8)
    hashed_pw = generate_password_hash(plain_password)

    users_collection.insert_one({
        "usn": usn,
        "email": email,
        "phone": phone,
        "username": username,
        "role": role,
        "password": hashed_pw,
        "skills": {"communication": 0, "technical": 0, "leadership": 0}
    })

    # Send password to student's email
    # email_sent = send_email(email, "Your Placement Portal Account", 
    #                         f"Hello {username},\\n\\nYour account has been created.\\nUsername: {username}\\nPassword: {plain_password}\\n\\nPlease log in and change your password after first login.")
    email_sent = send_email(
    email,
    "Your Placement Portal Account",
    f"Hello {username},\n\n"
    f"Your account has been created.\n"
    f"Username: {username}\n"
    f"Password: {plain_password}\n\n"
    "We’re glad to have you on board!"
)

    if not email_sent:
        print("Warning: Failed to send email to", email)

    print("User inserted successfully.")
    return jsonify({"message": "Account created successfully!"}), 201

# === Login API ===
@app.route("/api/login", methods=["POST"])
def login():
    data = request.json
    username = data.get("username")
    password = data.get("password")

    user = users_collection.find_one({"username": username})
    if not user or not check_password_hash(user["password"], password):
        return jsonify({"error": "Invalid username or password"}), 401

    session["user"] = {"username": username, "role": user["role"]}
    return jsonify({"message": "Logged in", "user": session["user"]})

@app.route("/api/logout", methods=["POST"])
def logout():
    session.pop("user", None)
    return jsonify({"message": "Logged out"})

@app.route("/api/me")
def me():
    return jsonify({"user": session.get("user")})

# === Protect Pages ===
@app.before_request
def protect_pages():
    protected = {
        "student.html": "student",
        "faculty.html": "faculty",
        "tpo.html": "tpo"
    }
    path = request.path.strip("/")
    if path in protected:
        user = session.get("user")
        if not user:
            return redirect("/login.html")
        if user["role"] != protected[path]:
            return "Forbidden", 403

# === Dashboards ===
@app.route("/student")
def student_dashboard():
    return render_template("student_dashboard.html")

@app.route("/company")
def company_dashboard():
    return render_template("company_dashboard.html")

if __name__ == "__main__":
    app.run(debug=True, port=8080)
