
Campus Career AI Portal - Demo
=============================

This is a simple static demo site (HTML/CSS/JS) that replicates the layout and style of the screenshots you provided:
- Hero section with gradient background and CTA buttons
- Three portal cards (Student / TPO / Faculty)
- Services grid with feature cards

How to use:
1. Unzip the package.
2. Open index.html in your browser (double-click or use Live Server in VS Code).
