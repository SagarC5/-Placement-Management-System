
// document.addEventListener('click', function(e){
//   if(e.target.matches('.card .btn, .btn.full')){
//     if(e.target.textContent.includes('Student')){
//       window.location.href = 'student-login.html';
//     } else if(e.target.textContent.includes('TPO')){
//       window.location.href = 'tpo-login.html';
//     } else if(e.target.textContent.includes('Faculty')){
//       window.location.href = 'faculty-login.html';
//     }
//   }
// });

document.addEventListener('click', function(e) {
  if (e.target.matches('[data-role]')) {
    const role = e.target.getAttribute('data-role');
    if (role === 'student') {
      window.location.href = 'student-login.html';
    } else if (role === 'tpo') {
      window.location.href = 'tpo-login.html';
    } else if (role === 'faculty') {
      window.location.href = 'faculty-login.html';
    }
  }
});
